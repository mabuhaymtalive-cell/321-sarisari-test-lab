# M10 TEST LAB Candidate — Quote Acceptance Patch

Status: NOT PASSED / NOT APPROVED FOR DEPLOYMENT.

This is an updated candidate prepared from the user's TEST LAB ZIP. It is isolated to the `m10-repair-candidate` branch and Firebase TEST LAB project `sarisari-test-lab`. Do not copy to production.

## Additional changes in this revision
- Added a one-time customer acceptance step after the owner confirms the final delivery fee.
- Customer acceptance is limited by Rules to the anonymous UID that owns the order.
- After acceptance, the owner can no longer change the delivery fee.
- For GCash/BDO, customer records the final payment amount and a separate post-quote buyer reference after accepting the final fee.
- Owner payment verification requires customer fee acceptance and uses a separate recipient-side reference.
- Owner order confirmation requires final fee acceptance; online payments must also be manually verified.
- Added T32–T35 security tests for quote acceptance, cross-customer denial, fee lock after acceptance, and required post-quote online reference.

## Static validation performed
- `node --check` passed for inline JavaScript in `index.html`.
- `node --check` passed for inline JavaScript in `owner.html`.
- `node --check` passed for `tests/security.rules.test.js`.
- Static assertions confirmed the new quote-acceptance rule and 35 test cases.

## Not yet validated
- Firestore Rules have NOT been compiled by the Firestore Emulator.
- The 35 Emulator tests have NOT been run. `npm install` timed out in this execution environment.
- No two-device browser test has been performed.
- No real or simulated end-to-end payment was performed.
- No live Firebase data, Rules, GitHub repository, or production project was changed.

## Validation sequence required
1. Upload these candidate files to the TEST LAB branch only.
2. Let GitHub Actions install dependencies and run `npm run test:emulator`.
3. Fix all test failures and inspect any Rules evaluation errors.
4. Manually test COD, GCash and BDO with fake/test data only.
5. Test same-device refresh and customer-only tracking.
6. Test owner fee quote → customer acceptance → payment verification → owner confirmation.
7. Confirm rider assignment compatibility; rider delivery completion PIN and stock transaction remain out of scope.
8. Only after all checks pass, review a separate deployment plan and obtain explicit approval.

## Protected items
- Production Firebase project `sarisaristore321-1f24b`
- Production GitHub repository `mabuhaymtalive-cell/321sarisaristore`
- Existing Budok payment/order
- Existing inventory backup and master files
